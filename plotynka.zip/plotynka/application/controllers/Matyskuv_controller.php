<?php defined('BASEPATH') OR exit('No direct script access allowed');
class Matyskuv_controller extends CI_Controller {
    function construct()
    {
        parent :: __construct();
        $this->load->model('Matyskuv_model'); 
    }
    public function hlavni_strana() {
        $data['polozky'] = $this->Matyskuv_model->get_menu_polozky();
        $this->load->view('lejaut/header', $data); 
        $this->load->view('content/hlavni_strana');
        $this->load->view('lejaut/footer');
    }
    public function prvni_strana() {
        $data['polozky'] = $this->Matyskuv_model->get_menu_polozky();
        $data['knihy'] = $this->Matyskuv_model->get_content(1);
        $this->load->view('lejaut/header', $data); 
        $this->load->view('content/prvni_strana', $data);
        $this->load->view('lejaut/footer');
    }
    public function druha_strana() {
        $data['polozky'] = $this->Matyskuv_model->get_menu_polozky();
        $data['knihy'] = $this->Matyskuv_model->get_content(2);
        $this->load->view('lejaut/header', $data); 
        $this->load->view('content/prvni_strana', $data);
        $this->load->view('lejaut/footer');
    }
    public function treti_strana() {
        $data['polozky'] = $this->Matyskuv_model->get_menu_polozky();
        $data['knihy'] = $this->Matyskuv_model->get_content(3);
        $this->load->view('lejaut/header', $data); 
        $this->load->view('content/prvni_strana', $data);
        $this->load->view('lejaut/footer');
    }
    public function ctvrta_strana() {
        $data['polozky'] = $this->Matyskuv_model->get_menu_polozky();
        $data['knihy'] = $this->Matyskuv_model->get_content(4);
        $this->load->view('lejaut/header', $data); 
        $this->load->view('content/prvni_strana', $data);
        $this->load->view('lejaut/footer');
    }
    public function autor($vytriprdel){
        $data['polozky'] = $this->Matyskuv_model->get_menu_polozky();
        $data['autor'] = $this->Matyskuv_model->get_autor($vytriprdel);
        $this->load->view('lejaut/header', $data); 
        $this->load->view('content/autor', $data);
        $this->load->view('lejaut/footer');
    
    }
}   