<?php 
        class hlavni_controller extends CI_controller {
            public function hlavni_strana()
            {
                $this->load->view('header+footer/header.php');
                $this->load->view('content/strana1.php');
                $this->load->view('header+footer/footer.php');
            }        
      
            public function vydavatele()
            {
                $this->load->view('header+footer/header.php');
                $this->load->view('content/strana2.php');
                $this->load->view('header+footer/footer.php');
            }
            public function autori()
            {
                $this->load->view('header+footer/header.php');
                $this->load->view('content/strana3.php');
                $this->load->view('header+footer/footer.php');
            }
        }    
?>