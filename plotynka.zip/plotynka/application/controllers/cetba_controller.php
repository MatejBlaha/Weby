<?php defined('BASEPATH') OR exit('No direct script access allowed');
    class cetba_controller extends CI_Controller {
        function  __construct(){
            parent :: __construct();
            $this->load->model('cetba_model');            
        }

    public function menu() {
    
        $data['polozky'] = $this->cetba_model->get_menu_polozky();
        $data['knihy1'] = $this->cetba_model->get_strana_1();

    $this->load->view('layout/hlavicka', $data);
    $this->load->view('content/prvni_strana', $data);
    $this->load->view('layout/paticka');

}
public function druha_strana() {
    
    $data['polozky'] = $this->cetba_model->get_menu_polozky();
    $data['knihy2'] = $this->cetba_model->get_strana_2();

$this->load->view('layout/hlavicka', $data);
$this->load->view('content/druha_strana', $data);
$this->load->view('layout/paticka');

}
public function treti_strana() {
    
    $data['polozky'] = $this->cetba_model->get_menu_polozky();
    $data['knihy3'] = $this->cetba_model->get_strana_3();

$this->load->view('layout/hlavicka', $data);
$this->load->view('content/treti_strana', $data);
$this->load->view('layout/paticka');
}

public function ctvrta_strana() {
    
    $data['polozky'] = $this->cetba_model->get_menu_polozky();
    $data['knihy4'] = $this->cetba_model->get_strana_4();

$this->load->view('layout/hlavicka', $data);
$this->load->view('content/ctvrta_strana', $data);
$this->load->view('layout/paticka');

}
}
