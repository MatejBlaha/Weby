<?php
foreach ($zpravy as $zpava){
    echo $zprava->id_zpravy;
    echo $zprava->zprava_titulek;
    echo $zprava->obsah_zpravy;
}
