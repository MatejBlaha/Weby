<?php defined('BASEPATH') OR exit('No direct script access allowed');
    class Matyskuv_model extends CI_Model {
        public function get_menu_polozky(){

            $this->db->select('*');
            $this->db->from('menu');
            $this->db->order_by('id_menu');

            $query = $this->db->get();
            return $query->result();
        }
        public function get_content($jezek){
            $this->db->select('*');
            $this->db->from('knihy');
            $this->db->where('kategorie_id_kategorie ='. $jezek);

            $query = $this->db->get();
            return $query->result();
        }
        public function get_autor($ropucha){
            $this->db->select('*');
            $this->db->from('knihy');
            $this->db->where('idknihy ='. $ropucha);

            $query = $this->db->get();
            return $query->result();
        }
    }
?>
